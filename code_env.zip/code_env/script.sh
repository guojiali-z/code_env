#!/bin/bash
Rscript ko_efficiency_analysis_code.R
python scwat_koe_pcr.py
Rscript correlation_analysis.R